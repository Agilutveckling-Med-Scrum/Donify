<template>
  <div style="background-color: blue;"></div>
</template>

<script>
export default {}
</script>

<style scoped></style>
